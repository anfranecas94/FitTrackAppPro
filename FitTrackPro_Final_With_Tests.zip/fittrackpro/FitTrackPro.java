package fittrackpro;

import java.util.*;
import java.util.concurrent.*;
import fittrackpro.model.*;
import fittrackpro.plan.*;
import fittrackpro.service.*;
import fittrackpro.report.*;
import fittrackpro.security.*;

public class FitTrackPro {
    public static void main(String[] args) {
        try {
            InputValidator validator = new InputValidator();
            UserInputHandler inputHandler = new UserInputHandler(validator);
            UserProfile user = inputHandler.collectUserProfile();

            ExecutorService executor = Executors.newFixedThreadPool(2);

            Callable<TrainingPlan> trainingTask = () -> {
                PlanFactory planFactory = new PlanFactory();
                return planFactory.createTrainingPlan(user);
            };

            Callable<DietPlan> dietTask = () -> {
                PlanFactory planFactory = new PlanFactory();
                return planFactory.createDietPlan(user);
            };

            Future<TrainingPlan> trainingFuture = executor.submit(trainingTask);
            Future<DietPlan> dietFuture = executor.submit(dietTask);

            TrainingPlan training = trainingFuture.get();
            DietPlan diet = dietFuture.get();

            executor.shutdown();

            ReportGenerator reportGenerator = new ReportGenerator();
            reportGenerator.printDailyPlan(user, training, diet);

            MonthlyReport monthly = new MonthlyReport(user, training, diet);
            monthly.generate();
        } catch (Exception e) {
            SafeLogger.log("An unexpected error occurred.");
        }
    }
}
