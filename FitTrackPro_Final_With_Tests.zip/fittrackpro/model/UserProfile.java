
package fittrackpro.model;

public class UserProfile {
    private String name;
    private int age;
    private double weight;
    private double height;
    private String goal;

    public UserProfile(String name, int age, double weight, double height, String goal) {
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.goal = goal;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public double getWeight() { return weight; }
    public double getHeight() { return height; }
    public String getGoal() { return goal; }
}
