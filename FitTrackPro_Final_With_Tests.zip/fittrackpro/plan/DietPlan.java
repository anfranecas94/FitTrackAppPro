
package fittrackpro.plan;

public class DietPlan {
    private String description;

    public DietPlan(String goal) {
        this.description = switch (goal) {
            case "lose_weight" -> "Low calorie diet";
            case "build_muscle" -> "High protein diet";
            default -> "Balanced diet";
        };
    }

    public String getDescription() {
        return description;
    }
}
