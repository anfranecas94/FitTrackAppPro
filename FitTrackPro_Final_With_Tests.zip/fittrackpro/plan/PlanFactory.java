
package fittrackpro.plan;

import fittrackpro.model.UserProfile;

public class PlanFactory {
    public TrainingPlan createTrainingPlan(UserProfile user) {
        TrainingPlan plan = new TrainingPlan();
        plan.addComponent(new Workout("Cardio"));
        plan.addComponent(new Workout("Strength"));
        return plan;
    }

    public DietPlan createDietPlan(UserProfile user) {
        return new DietPlan(user.getGoal());
    }
}
