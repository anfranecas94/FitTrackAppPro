
package fittrackpro.plan;

public class TrainingPlan extends WorkoutPlan {
    public TrainingPlan() {
        super();
    }
}
