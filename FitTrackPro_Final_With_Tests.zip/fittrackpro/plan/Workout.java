
package fittrackpro.plan;

public class Workout implements WorkoutComponent {
    private String type;

    public Workout(String type) {
        this.type = type;
    }

    public String getDescription() {
        return "Workout type: " + type;
    }
}
