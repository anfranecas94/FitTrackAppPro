
package fittrackpro.plan;

public interface WorkoutComponent {
    String getDescription();
}
