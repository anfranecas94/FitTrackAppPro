
package fittrackpro.plan;

import java.util.*;

public class WorkoutPlan implements WorkoutComponent {
    private List<WorkoutComponent> components = new ArrayList<>();

    public void addComponent(WorkoutComponent component) {
        components.add(component);
    }

    public String getDescription() {
        StringBuilder sb = new StringBuilder();
        for (WorkoutComponent c : components) {
            sb.append(c.getDescription()).append("\n");
        }
        return sb.toString();
    }

    public List<WorkoutComponent> getComponents() {
        return components;
    }
}
