
package fittrackpro.report;

import fittrackpro.model.UserProfile;
import fittrackpro.plan.*;

public class MonthlyReport {
    private UserProfile user;
    private TrainingPlan training;
    private DietPlan diet;

    public MonthlyReport(UserProfile user, TrainingPlan training, DietPlan diet) {
        this.user = user;
        this.training = training;
        this.diet = diet;
    }

    public void generate() {
        System.out.println("Monthly Summary for " + user.getName());
        System.out.println("Workouts completed: 20 sessions");
        System.out.println("Diet consistency: Good");
    }
}
