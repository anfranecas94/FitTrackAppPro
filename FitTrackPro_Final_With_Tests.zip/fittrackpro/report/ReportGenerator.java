
package fittrackpro.report;

import fittrackpro.model.UserProfile;
import fittrackpro.plan.*;

public class ReportGenerator {
    public void printDailyPlan(UserProfile user, TrainingPlan training, DietPlan diet) {
        System.out.println("User: " + user.getName());
        System.out.println("Training Plan:");
        System.out.println(training.getDescription());
        System.out.println("Diet Plan:");
        System.out.println(diet.getDescription());
    }
}
