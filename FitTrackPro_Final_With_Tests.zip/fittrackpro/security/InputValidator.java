
package fittrackpro.security;

public class InputValidator {
    public boolean isValid(String input) {
        return input != null && !input.isBlank();
    }
}
