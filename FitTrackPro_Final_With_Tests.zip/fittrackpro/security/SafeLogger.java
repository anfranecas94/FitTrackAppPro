
package fittrackpro.security;

public class SafeLogger {
    public static void log(String message) {
        System.err.println("[LOG] " + message);
    }
}
