
package fittrackpro.service;

import java.util.Scanner;
import fittrackpro.model.UserProfile;
import fittrackpro.security.InputValidator;

public class UserInputHandler {
    private InputValidator validator;
    private Scanner scanner = new Scanner(System.in);

    public UserInputHandler(InputValidator validator) {
        this.validator = validator;
    }

    public UserProfile collectUserProfile() {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter age: ");
        int age = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter weight: ");
        double weight = Double.parseDouble(scanner.nextLine());
        System.out.print("Enter height: ");
        double height = Double.parseDouble(scanner.nextLine());
        System.out.print("Enter goal (lose_weight/build_muscle): ");
        String goal = scanner.nextLine();
        return new UserProfile(name, age, weight, height, goal);
    }
}
