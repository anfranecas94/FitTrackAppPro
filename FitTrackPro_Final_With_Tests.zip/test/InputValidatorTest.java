
package test;

import fittrackpro.security.InputValidator;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class InputValidatorTest {

    @Test
    public void testValidInput() {
        String result = InputValidator.validateString("Cardio");
        assertEquals("Cardio", result);
    }

    @Test
    public void testInvalidInput() {
        String result = InputValidator.validateString("");
        assertEquals("N/A", result);
    }
}
