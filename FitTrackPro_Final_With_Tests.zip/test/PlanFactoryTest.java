
package test;

import fittrackpro.plan.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PlanFactoryTest {

    @Test
    public void testCreateWorkoutPlan() {
        Plan plan = PlanFactory.createPlan("workout");
        assertTrue(plan instanceof WorkoutPlan);
    }

    @Test
    public void testCreateDietPlan() {
        Plan plan = PlanFactory.createPlan("diet");
        assertTrue(plan instanceof DietPlan);
    }

    @Test
    public void testCreateInvalidPlan() {
        assertThrows(IllegalArgumentException.class, () -> {
            PlanFactory.createPlan("invalid");
        });
    }
}
