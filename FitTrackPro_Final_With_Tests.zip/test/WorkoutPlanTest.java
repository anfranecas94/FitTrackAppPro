
package test;

import fittrackpro.plan.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WorkoutPlanTest {

    @Test
    public void testAddComponent() {
        WorkoutPlan plan = new WorkoutPlan();
        plan.add(new Workout("Pushups", 10));
        assertEquals(1, plan.getComponents().size());
    }
}
